package com.example.car.service.email;

import com.example.car.model.email.EmailDTO;

public interface EmailService {
public void sendMail(EmailDTO dto);

}
