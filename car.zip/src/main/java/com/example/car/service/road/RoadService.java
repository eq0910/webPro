package com.example.car.service.road;

import org.springframework.stereotype.Service;

@Service
public interface RoadService {
	
}
