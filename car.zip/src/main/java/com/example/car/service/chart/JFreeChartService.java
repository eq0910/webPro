package com.example.car.service.chart;

import org.jfree.chart.JFreeChart;

public interface JFreeChartService {
public JFreeChart createChart();
}
