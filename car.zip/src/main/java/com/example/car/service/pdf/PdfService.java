package com.example.car.service.pdf;

public interface PdfService {
	public String createPdf();
}
