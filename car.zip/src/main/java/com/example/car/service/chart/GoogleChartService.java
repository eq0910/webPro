package com.example.car.service.chart;

import org.json.simple.JSONObject;

public interface GoogleChartService {
public JSONObject getChartData();
}
