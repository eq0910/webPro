package com.example.car.service.admin;

import com.example.car.model.member.dto.MemberDTO;

public interface AdminService {
	public String loginCheck(MemberDTO dto);

}
