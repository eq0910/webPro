package com.example.car.model.message.dao;

public interface PointDAO {

	public void updatePoint(String userid, int point);
	
}
