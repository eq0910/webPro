package com.example.car.model.admin;

import com.example.car.model.member.dto.MemberDTO;

public interface AdminDAO {
	public String loginCheck(MemberDTO dto);

}
